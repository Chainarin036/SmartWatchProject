package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.databinding.ActivityMainBinding;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.Timer;

public class MainActivity extends Activity implements SensorEventListener {

    private TextView mTextView,accText;
    private ActivityMainBinding binding;
    private Button button1,onButton;
    private boolean trainingOn = false;
    Vibrator vibrator;
    Handler loopVi;
    private SensorManager sensorManeger;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        accText = findViewById(R.id.textAcc);
        button1 = findViewById(R.id.button3);
        onButton = findViewById(R.id.buttonOn);
        mTextView = findViewById(R.id.textView);
        sensorManeger = (SensorManager) getSystemService(SENSOR_SERVICE);
        Sensor accleroSensor = sensorManeger.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor light = sensorManeger.getDefaultSensor(Sensor.TYPE_LIGHT);
//        Sensor orienTation = sensorManeger.getDefaultSensor(Sensor.TYPE_ORIENTATION);
        sensorManeger.registerListener(this, accleroSensor, SensorManager.SENSOR_DELAY_UI);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        button1.setEnabled(false);

        onButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onButton.getText() == "ON"){
                    trainingOn = true;
                    onButton.setText("OFF");
                    button1.setEnabled(true);
                }else{
                    trainingOn = false;
                    onButton.setText("ON");
                    button1.setEnabled(false);
                }

            }
        });

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (trainingOn) {
                    float[] v = accQueue.get(accQueue.size() - 1);
                    String a = "X:" + v[0] + "\nY:" + v[1] + "\nZ:" + v[2];
//                Toast.makeText(MainActivity.this, a, Toast.LENGTH_SHORT).show();
                    timerOn = true;
                    loopVi = new Handler();
                    loopVi.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            vibrator.vibrate(200);
                        }
                    }, 1);

                    new CountDownTimer(4000, 1000) {
                        public void onTick(long millisUntilFinished) {
                            mTextView.setText("Seconds remaining: " + millisUntilFinished / 1000);
                            timerOn = true;
                        }

                        public void onFinish() {
                            timerOn = false;
                            vibrator.vibrate(200);
                        }
                    }.start();
                }

            }
        });
        sensorManeger = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

    }

//    @Override
//    protected void onRestart() {
//        super.onRestart();
//    }

    protected void onPause() {
        super.onPause();
//        sensorManeger.unregisterListener(this);
    }
    Stack<float[]> accQueue = new Stack<>();
    boolean timerOn = false;

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (accQueue.size() >= 50){
            accQueue.remove(0);
        }

        float [] val = new float[]{sensorEvent.values[0],sensorEvent.values[1],sensorEvent.values[2]};
        accQueue.push(val);
        double ac = calAcc(val);
        if (ac>40.0){
            vibrator.vibrate(2000);
        }
        accText.setText(String.valueOf(ac));
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    double calAcc(float[] inp){
        double x_pow = Math.pow(inp[0],2);
        double y_pow = Math.pow(inp[1],2);
        double z_pow = Math.pow(inp[2],2);
        double com = x_pow + y_pow + z_pow;
        double result = Math.sqrt(com);
        return result;
    }


}